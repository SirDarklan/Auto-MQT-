from __future__ import annotations

import argparse
from pathlib import Path
from statistics import mean
from typing import Any

import torch
import yaml
from torch import nn
from torch.utils.data import DataLoader, Dataset, random_split

from data_utils import feature_from_example, load_jsonl
from router_model import LateFusionRouter, RouterConfig, budget_to_index


class OracleBudgetDataset(Dataset):
    def __init__(self, rows: list[dict[str, Any]], config: RouterConfig) -> None:
        self.rows = rows
        self.config = config

    def __len__(self) -> int:
        return len(self.rows)

    def __getitem__(self, index: int) -> dict[str, torch.Tensor]:
        row = self.rows[index]
        prompt_feature = feature_from_example(
            row,
            field="prompt_embedding",
            fallback_text=row["prompt"],
            dim=self.config.prompt_dim,
        )
        image_feature = feature_from_example(
            row,
            field="image_embedding",
            fallback_text=row["image"],
            dim=self.config.image_dim,
        )
        label = budget_to_index(row["oracle_budget"], self.config.budgets)
        return {
            "prompt_features": torch.tensor(prompt_feature, dtype=torch.float32),
            "image_features": torch.tensor(image_feature, dtype=torch.float32),
            "label": torch.tensor(label, dtype=torch.long),
            "oracle_budget": torch.tensor(row["oracle_budget"], dtype=torch.float32),
        }


def load_router_config(path: str | Path) -> tuple[RouterConfig, dict[str, Any]]:
    with Path(path).open("r", encoding="utf-8") as f:
        raw = yaml.safe_load(f)
    config = RouterConfig(
        budgets=[int(v) for v in raw["budgets"]],
        prompt_dim=int(raw["prompt_dim"]),
        image_dim=int(raw["image_dim"]),
        hidden_dim=int(raw["hidden_dim"]),
        dropout=float(raw["dropout"]),
        confidence_fallback_threshold=float(raw.get("confidence_fallback_threshold", 0.0)),
    )
    return config, raw


def cost_aware_loss(
    logits: torch.Tensor,
    labels: torch.Tensor,
    budgets: list[int],
    lambda_cost: float,
    cost_power: float,
) -> torch.Tensor:
    ce = nn.functional.cross_entropy(logits, labels)
    probs = torch.softmax(logits, dim=-1)
    budget_tensor = torch.tensor(budgets, dtype=torch.float32, device=logits.device)
    normalized_cost = (budget_tensor / budget_tensor.max()).pow(cost_power)
    expected_cost = (probs * normalized_cost).sum(dim=-1).mean()
    return ce + lambda_cost * expected_cost


def evaluate_epoch(model: LateFusionRouter, loader: DataLoader, device: torch.device) -> dict[str, float]:
    model.eval()
    total = 0
    correct = 0
    predicted_budgets: list[int] = []
    oracle_budgets: list[int] = []

    with torch.no_grad():
        for batch in loader:
            prompt = batch["prompt_features"].to(device)
            image = batch["image_features"].to(device)
            labels = batch["label"].to(device)
            logits = model(prompt, image)
            pred = logits.argmax(dim=-1)
            correct += int((pred == labels).sum().item())
            total += int(labels.numel())
            for idx in pred.cpu().tolist():
                predicted_budgets.append(model.config.budgets[idx])
            oracle_budgets.extend(int(v) for v in batch["oracle_budget"].cpu().tolist())

    regret = mean(max(0, pred - oracle) for pred, oracle in zip(predicted_budgets, oracle_budgets))
    under_budget_rate = mean(float(pred < oracle) for pred, oracle in zip(predicted_budgets, oracle_budgets))
    return {
        "accuracy": correct / max(1, total),
        "avg_predicted_budget": mean(predicted_budgets) if predicted_budgets else 0.0,
        "budget_regret": regret,
        "under_budget_rate": under_budget_rate,
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--labels", required=True, help="Oracle-label JSONL from oracle_labeling.py")
    parser.add_argument("--config", default="configs/router.yaml")
    parser.add_argument("--mode", choices=["prompt", "image", "multimodal"], default="multimodal")
    parser.add_argument("--out", default="checkpoints/router_multimodal.pt")
    parser.add_argument("--val-fraction", type=float, default=0.2)
    parser.add_argument("--seed", type=int, default=7)
    args = parser.parse_args()

    torch.manual_seed(args.seed)
    config, raw_config = load_router_config(args.config)
    rows = load_jsonl(args.labels)
    dataset = OracleBudgetDataset(rows, config)

    if len(dataset) < 2:
        raise ValueError("Need at least two oracle-labeled examples to train/validate a router.")
    val_size = max(1, int(len(dataset) * args.val_fraction))
    train_size = len(dataset) - val_size
    if train_size < 1:
        train_size = 1
        val_size = len(dataset) - train_size
    train_data, val_data = random_split(
        dataset,
        [train_size, val_size],
        generator=torch.Generator().manual_seed(args.seed),
    )

    loader_kwargs = {"batch_size": int(raw_config["batch_size"])}
    train_loader = DataLoader(train_data, shuffle=True, **loader_kwargs)
    val_loader = DataLoader(val_data, shuffle=False, **loader_kwargs)

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    model = LateFusionRouter(config, mode=args.mode).to(device)
    optimizer = torch.optim.AdamW(
        model.parameters(),
        lr=float(raw_config["learning_rate"]),
        weight_decay=float(raw_config["weight_decay"]),
    )

    best_val = -1.0
    out_path = Path(args.out)
    out_path.parent.mkdir(parents=True, exist_ok=True)

    for epoch in range(1, int(raw_config["epochs"]) + 1):
        model.train()
        losses = []
        for batch in train_loader:
            prompt = batch["prompt_features"].to(device)
            image = batch["image_features"].to(device)
            labels = batch["label"].to(device)
            logits = model(prompt, image)
            loss = cost_aware_loss(
                logits=logits,
                labels=labels,
                budgets=config.budgets,
                lambda_cost=float(raw_config["lambda_cost"]),
                cost_power=float(raw_config["cost_power"]),
            )
            optimizer.zero_grad()
            loss.backward()
            optimizer.step()
            losses.append(float(loss.item()))

        metrics = evaluate_epoch(model, val_loader, device)
        print(
            f"epoch={epoch:02d} loss={mean(losses):.4f} "
            f"val_acc={metrics['accuracy']:.4f} "
            f"avg_budget={metrics['avg_predicted_budget']:.2f} "
            f"regret={metrics['budget_regret']:.2f} "
            f"under={metrics['under_budget_rate']:.4f}"
        )
        if metrics["accuracy"] > best_val:
            best_val = metrics["accuracy"]
            torch.save(
                {
                    "model_state": model.state_dict(),
                    "router_config": config.__dict__,
                    "raw_config": raw_config,
                    "mode": args.mode,
                    "best_val_accuracy": best_val,
                },
                out_path,
            )

    print(f"saved: {out_path}")


if __name__ == "__main__":
    main()
