from __future__ import annotations

from dataclasses import dataclass

import torch
from torch import nn


@dataclass(frozen=True)
class RouterConfig:
    budgets: list[int]
    prompt_dim: int
    image_dim: int
    hidden_dim: int
    dropout: float
    confidence_fallback_threshold: float = 0.0


class LateFusionRouter(nn.Module):
    def __init__(self, config: RouterConfig, mode: str = "multimodal") -> None:
        super().__init__()
        if mode not in {"prompt", "image", "multimodal"}:
            raise ValueError(f"Unknown router mode: {mode}")
        self.config = config
        self.mode = mode

        input_dim = 0
        if mode in {"prompt", "multimodal"}:
            input_dim += config.prompt_dim
        if mode in {"image", "multimodal"}:
            input_dim += config.image_dim

        self.net = nn.Sequential(
            nn.Linear(input_dim, config.hidden_dim),
            nn.GELU(),
            nn.Dropout(config.dropout),
            nn.Linear(config.hidden_dim, config.hidden_dim),
            nn.GELU(),
            nn.Dropout(config.dropout),
            nn.Linear(config.hidden_dim, len(config.budgets)),
        )

    def forward(self, prompt_features: torch.Tensor, image_features: torch.Tensor) -> torch.Tensor:
        pieces = []
        if self.mode in {"prompt", "multimodal"}:
            pieces.append(prompt_features)
        if self.mode in {"image", "multimodal"}:
            pieces.append(image_features)
        return self.net(torch.cat(pieces, dim=-1))


def budget_to_index(budget: int, budgets: list[int]) -> int:
    try:
        return budgets.index(int(budget))
    except ValueError as exc:
        raise ValueError(f"Budget {budget} not in configured budgets {budgets}") from exc


def predict_budget(
    logits: torch.Tensor,
    budgets: list[int],
    confidence_fallback_threshold: float = 0.0,
) -> tuple[int, float]:
    probs = torch.softmax(logits, dim=-1)
    confidence, index = torch.max(probs, dim=-1)
    chosen_index = int(index.item())
    if confidence_fallback_threshold and confidence.item() < confidence_fallback_threshold:
        chosen_index = min(chosen_index + 1, len(budgets) - 1)
    return int(budgets[chosen_index]), float(confidence.item())
