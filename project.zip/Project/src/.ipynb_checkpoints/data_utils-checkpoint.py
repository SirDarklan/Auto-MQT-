from __future__ import annotations

import hashlib
import json
from pathlib import Path
from typing import Any, Iterable

import numpy as np


def load_jsonl(path: str | Path) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    with Path(path).open("r", encoding="utf-8") as f:
        for line in f:
            if line.strip():
                rows.append(json.loads(line))
    return rows


def write_jsonl(rows: Iterable[dict[str, Any]], path: str | Path) -> None:
    out_path = Path(path)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    with out_path.open("w", encoding="utf-8") as f:
        for row in rows:
            f.write(json.dumps(row) + "\n")


def normalize_answer(text: str) -> str:
    return " ".join(text.lower().strip().split())


def exact_match(prediction: str, answer: str) -> float:
    return float(normalize_answer(prediction) == normalize_answer(answer))


def stable_hash_vector(text: str, dim: int) -> np.ndarray:
    """Deterministic feature fallback for pipeline tests before real embeddings exist."""
    vector = np.zeros(dim, dtype=np.float32)
    tokens = normalize_answer(text).split()
    for token in tokens or [text]:
        digest = hashlib.blake2b(token.encode("utf-8"), digest_size=8).digest()
        value = int.from_bytes(digest, byteorder="little", signed=False)
        index = value % dim
        sign = 1.0 if ((value >> 8) & 1) else -1.0
        vector[index] += sign
    norm = np.linalg.norm(vector)
    if norm > 0:
        vector /= norm
    return vector


def feature_from_example(
    example: dict[str, Any],
    field: str,
    fallback_text: str,
    dim: int,
) -> np.ndarray:
    if field in example:
        return np.asarray(example[field], dtype=np.float32)
    return stable_hash_vector(fallback_text, dim)
