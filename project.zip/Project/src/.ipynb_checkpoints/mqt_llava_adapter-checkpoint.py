from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from time import perf_counter
from typing import Protocol


@dataclass(frozen=True)
class GenerationResult:
    text: str
    visual_tokens: int
    latency_s: float


class MqtLlavaBackend(Protocol):
    def generate(
        self,
        image_path: str | Path,
        prompt: str,
        visual_tokens: int,
        max_new_tokens: int = 64,
    ) -> str:
        ...


class PlaceholderMqtLlavaBackend:
    """Replace this with the actual MQT-LLaVA repo/checkpoint inference call."""

    def generate(
        self,
        image_path: str | Path,
        prompt: str,
        visual_tokens: int,
        max_new_tokens: int = 64,
    ) -> str:
        raise NotImplementedError(
            "Wire this adapter to MQT-LLaVA. The key argument to pass through is "
            "`visual_tokens`, sometimes named m, num_query_tokens, or token_budget "
            "depending on the repo implementation."
        )


class TimedMqtLlava:
    def __init__(self, backend: MqtLlavaBackend) -> None:
        self.backend = backend

    def generate(
        self,
        image_path: str | Path,
        prompt: str,
        visual_tokens: int,
        max_new_tokens: int = 64,
    ) -> GenerationResult:
        start = perf_counter()
        text = self.backend.generate(
            image_path=image_path,
            prompt=prompt,
            visual_tokens=visual_tokens,
            max_new_tokens=max_new_tokens,
        )
        return GenerationResult(
            text=text,
            visual_tokens=visual_tokens,
            latency_s=perf_counter() - start,
        )
