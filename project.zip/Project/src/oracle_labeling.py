from __future__ import annotations

import argparse
from pathlib import Path
from statistics import mean

from data_utils import append_jsonl, answers_for_example, format_prompt, load_jsonl, score_prediction
from mqt_llava_adapter import TimedMqtLlava, build_mqt_llava_backend


DEFAULT_BUDGETS = [2, 4, 8, 16, 36, 64, 144, 256]


def choose_oracle_budget(
    scored_budgets: list[dict],
    full_budget: int,
    tolerance: float = 0.0,
) -> tuple[int, float]:
    reference_score = max(row["score"] for row in scored_budgets)
    if reference_score <= 0.0:
        full_rows = [row for row in scored_budgets if row["visual_tokens"] == full_budget]
        full_score = full_rows[0]["score"] if full_rows else 0.0
        return int(full_budget), float(full_score)

    threshold = max(0.0, reference_score - tolerance)

    for row in sorted(scored_budgets, key=lambda item: item["visual_tokens"]):
        if row["score"] >= threshold:
            return int(row["visual_tokens"]), float(row["score"])
    best = max(scored_budgets, key=lambda item: (item["score"], -item["visual_tokens"]))
    return int(best["visual_tokens"]), float(best["score"])


def example_key(example: dict, index: int) -> str:
    return str(example.get("example_id", index))


def completed_keys(path: str | Path) -> set[str]:
    out_path = Path(path)
    if not out_path.exists():
        return set()
    return {str(row["example_id"]) for row in load_jsonl(out_path) if "example_id" in row}


def label_one_example(
    model: TimedMqtLlava,
    example: dict,
    index: int,
    budgets: list[int],
    tolerance: float,
    max_new_tokens: int,
    score_key: str,
    prompt_style: str,
) -> dict:
    full_budget = max(budgets)
    model_prompt = format_prompt(
        example["prompt"],
        task=example.get("task"),
        prompt_style=prompt_style,
    )
    scored_budgets = []

    for budget in budgets:
        result = model.generate(
            image_path=example["image"],
            prompt=model_prompt,
            visual_tokens=budget,
            max_new_tokens=max_new_tokens,
        )
        answers = answers_for_example(example)
        scores = score_prediction(result.text, answers) if answers else {"exact_match": 0.0, "relaxed_match": 0.0}
        scored_budgets.append(
            {
                "visual_tokens": budget,
                "prediction": result.text,
                "score": scores[score_key],
                **scores,
                "latency_s": result.latency_s,
            }
        )

    oracle_budget, oracle_score = choose_oracle_budget(
        scored_budgets=scored_budgets,
        full_budget=full_budget,
        tolerance=tolerance,
    )
    return {
        **example,
        "model_prompt": model_prompt,
        "oracle_score_key": score_key,
        "oracle_budget": oracle_budget,
        "oracle_score": oracle_score,
        "budget_results": scored_budgets,
        "example_id": example_key(example, index),
    }


def label_examples_to_jsonl(
    examples: list[dict],
    out: str | Path,
    budgets: list[int],
    tolerance: float,
    max_new_tokens: int,
    score_key: str,
    prompt_style: str,
    limit: int | None,
    resume: bool,
) -> list[dict]:
    model = TimedMqtLlava(build_mqt_llava_backend())
    done = completed_keys(out) if resume else set()
    written_rows = []
    processed = 0

    for index, example in enumerate(examples):
        key = example_key(example, index)
        if key in done:
            print(f"skip existing example_id={key}", flush=True)
            continue
        if limit is not None and processed >= limit:
            break

        print(f"label example {processed + 1}: example_id={key}", flush=True)
        row = label_one_example(
            model=model,
            example=example,
            index=index,
            budgets=budgets,
            tolerance=tolerance,
            max_new_tokens=max_new_tokens,
            score_key=score_key,
            prompt_style=prompt_style,
        )
        append_jsonl(row, out)
        written_rows.append(row)
        processed += 1
        print(
            f"wrote example_id={key} oracle_budget={row['oracle_budget']} "
            f"oracle_score={row['oracle_score']}",
            flush=True,
        )

    return written_rows


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--data", required=True, help="Input JSONL with image, prompt, answer")
    parser.add_argument("--out", default="data/oracle_labels.jsonl")
    parser.add_argument("--budgets", nargs="+", type=int, default=DEFAULT_BUDGETS)
    parser.add_argument("--tolerance", type=float, default=0.0)
    parser.add_argument("--max-new-tokens", type=int, default=64)
    parser.add_argument("--score-key", choices=["exact_match", "relaxed_match"], default="relaxed_match")
    parser.add_argument("--prompt-style", choices=["none", "short"], default="short")
    parser.add_argument("--limit", type=int, default=None, help="Maximum new examples to label this run")
    parser.add_argument("--no-resume", action="store_true", help="Do not skip example_ids already in --out")
    args = parser.parse_args()

    examples = load_jsonl(args.data)
    rows = label_examples_to_jsonl(
        examples=examples,
        out=args.out,
        budgets=args.budgets,
        tolerance=args.tolerance,
        max_new_tokens=args.max_new_tokens,
        score_key=args.score_key,
        prompt_style=args.prompt_style,
        limit=args.limit,
        resume=not args.no_resume,
    )

    print(f"new_examples: {len(rows)}")
    if rows:
        print(f"avg_new_oracle_budget: {mean(row['oracle_budget'] for row in rows):.2f}")
    print(f"output: {args.out}")


if __name__ == "__main__":
    main()
