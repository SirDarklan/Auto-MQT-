# Auto-MQT Token Routing Starter

This scaffold implements the proposal workflow for Auto-MQT: generate oracle token-budget labels, train a small router, and compare adaptive routing against fixed-budget MQT-LLaVA baselines.

## Data Format

The project uses JSONL manifests as the canonical cache, even when the raw data comes from Hugging Face. Each row contains normalized fields:

```json
{"dataset": "textvqa", "split": "train", "example_id": "textvqa_train_12", "image": "data/images/textvqa/train/textvqa_train_12.jpg", "prompt": "what word is written on the sign?", "answer": "stop", "answers": ["stop"], "task": "ocr"}
```

The `task` field is optional. If omitted, the rule-based baseline in `src/task_token_policy.py` uses keyword rules from `configs/task_token_policy.yaml`.

Router training expects oracle-labeled JSONL produced by `src/oracle_labeling.py`. If you already have frozen prompt/image embeddings, you can include them as `prompt_embedding` and `image_embedding` arrays. Otherwise the training script uses deterministic hashed fallback features so the pipeline can be tested before the real MQT-LLaVA feature extractor is wired in.

## Prepare Hugging Face Datasets

Edit `configs/hf_datasets.yaml` to choose dataset mirrors, splits, and subset sizes for VQAv2, GQA, TextVQA, and ScienceQA-IMG. Then create local cached manifests:

```bash
python3 src/prepare_hf_datasets.py \
  --config configs/hf_datasets.yaml \
  --train-limit 5 \
  --eval-limit 5
```

This writes:

```text
data/manifests/train.jsonl
data/manifests/eval.jsonl
data/images/
```

Verify the manifests before running MQT-LLaVA:

```bash
python3 src/verify_manifest.py --manifest data/manifests/train.jsonl
python3 src/verify_manifest.py --manifest data/manifests/eval.jsonl
```

You can prepare one dataset at a time:

```bash
python3 src/prepare_hf_datasets.py --datasets textvqa --train-limit 5 --eval-limit 5
```

## Run Fixed Baselines

```bash
python3 src/evaluate_token_policy.py --data data/manifests/eval.jsonl --fixed-budget 8 --out results/fixed_8.jsonl
python3 src/evaluate_token_policy.py --data data/manifests/eval.jsonl --fixed-budget 36 --out results/fixed_36.jsonl
python3 src/evaluate_token_policy.py --data data/manifests/eval.jsonl --fixed-budget 256 --out results/fixed_256.jsonl
```

## Generate Oracle Labels

Run the frozen MQT-LLaVA model at each candidate budget and choose the smallest sufficient budget.

```bash
python3 src/oracle_labeling.py \
  --data data/manifests/train.jsonl \
  --out data/manifests/oracle_train.jsonl \
  --budgets 2 4 8 16 36 64 144 256
```

By default, sufficiency means exact match with the answer. You can loosen this for noisy metrics with `--tolerance`.

## Train Routers

Train proposal baselines:

```bash
KMP_DUPLICATE_LIB_OK=TRUE python3 src/train_router.py \
  --labels data/manifests/oracle_train.jsonl \
  --mode prompt \
  --out checkpoints/router_prompt.pt

KMP_DUPLICATE_LIB_OK=TRUE python3 src/train_router.py \
  --labels data/manifests/oracle_train.jsonl \
  --mode image \
  --out checkpoints/router_image.pt

KMP_DUPLICATE_LIB_OK=TRUE python3 src/train_router.py \
  --labels data/manifests/oracle_train.jsonl \
  --mode multimodal \
  --out checkpoints/router_multimodal.pt
```

`KMP_DUPLICATE_LIB_OK=TRUE` is included because this local macOS environment currently reports an OpenMP duplicate-runtime issue when importing PyTorch.

## Evaluate Learned Routing

```bash
KMP_DUPLICATE_LIB_OK=TRUE python3 src/evaluate_router.py \
  --data data/manifests/eval.jsonl \
  --checkpoint checkpoints/router_multimodal.pt \
  --out results/router_multimodal.jsonl
```

## Run Rule-Based Task Routing

```bash
python3 src/evaluate_token_policy.py \
  --data data/manifests/eval.jsonl \
  --policy configs/task_token_policy.yaml \
  --out results/rule_task_aware.jsonl
```

## Model Adapter

Point this project at your cloned MQT-LLaVA repository:

```bash
export MQT_LLAVA_REPO=/absolute/path/to/MQT-LLaVA
export MQT_LLAVA_MODEL_PATH=gordonhu/MQT-LLaVA-7b
```

Then run any evaluation script from this project. The adapter in `src/mqt_llava_adapter.py` imports:

```python
from llava.eval.run_llava import eval_model
```

and passes our selected budget through the repo's official argument:

```python
num_visual_tokens=<budget>
```

Example:

```bash
MQT_LLAVA_REPO=/absolute/path/to/MQT-LLaVA \
python3 src/evaluate_token_policy.py \
  --data data/manifests/eval.jsonl \
  --fixed-budget 36 \
  --out results/fixed_36.jsonl
```

If you installed MQT-LLaVA into the active Python environment and do not want to pass a repo path, use:

```bash
MQT_LLAVA_USE_INSTALLED=1 python3 src/evaluate_token_policy.py --data data/eval.jsonl --fixed-budget 36
```

Depending on the repo, that argument may be named something like:

- `m`
- `num_query_tokens`
- `token_budget`
- `visual_tokens`

For this repository's README, the relevant name is `num_visual_tokens`. Keep the outer evaluation code unchanged so all experiments are comparable.

The current adapter calls the public `eval_model` function. This is the simplest connection and should work for initial experiments. For large oracle-label generation, it may be worth replacing it later with a persistent loaded model so the 7B checkpoint is not reloaded for every example.

## Proposal Files

- `src/oracle_labeling.py`: Step 1, oracle budget labeling.
- `src/prepare_hf_datasets.py`: converts Hugging Face subsets into local JSONL manifests.
- `src/verify_manifest.py`: validates manifest fields and saved images.
- `src/router_model.py`: late-fusion MLP router for prompt-only, image-only, and multimodal ablations.
- `src/train_router.py`: Step 2/3, router training with cost-aware loss.
- `src/evaluate_router.py`: Step 4, adaptive inference policy with optional confidence fallback.
- `src/evaluate_token_policy.py`: fixed-budget and rule-based baselines.
